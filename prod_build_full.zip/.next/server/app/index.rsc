1:"$Sreact.fragment"
2:I[479520,["/_next/static/chunks/1h6_r7a6a9osl.js","/_next/static/chunks/1ntn7efqc-iiw.js","/_next/static/chunks/3o-yin-2r9ddp.js","/_next/static/chunks/3aiu8uhh9ykx9.js","/_next/static/chunks/1s50t5yz2fnzr.js","/_next/static/chunks/2rpwzaa97r4w2.js"],""]
7:I[168027,["/_next/static/chunks/1h6_r7a6a9osl.js","/_next/static/chunks/1ntn7efqc-iiw.js","/_next/static/chunks/3o-yin-2r9ddp.js","/_next/static/chunks/3aiu8uhh9ykx9.js","/_next/static/chunks/1s50t5yz2fnzr.js","/_next/static/chunks/2rpwzaa97r4w2.js"],"default",1]
:HL["/_next/static/chunks/0563c538fyhde.css","style"]
3:Tc62,
              (function() {
                function sanitizeInput(el) {
                  if (!el) return;
                  if (el.tagName === 'FORM') {
                    el.setAttribute('autocomplete', 'off');
                    return;
                  }
                  if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
                    const isPasswordType = el.type === 'password';
                    if (!isPasswordType) {
                      el.setAttribute('autocomplete', 'off');
                      el.setAttribute('autocorrect', 'off');
                      el.setAttribute('autocapitalize', 'off');
                      el.setAttribute('spellcheck', 'false');
                      el.setAttribute('aria-autocomplete', 'none');
                      el.setAttribute('data-lpignore', 'true');
                      el.setAttribute('data-1p-ignore', 'true');
                      el.setAttribute('data-bwignore', 'true');
                      el.setAttribute('data-bitwarden-watching', 'false');
                      
                      const nameOrPlaceholder = (el.name || el.placeholder || el.id || '').toLowerCase();
                      if (nameOrPlaceholder.includes('mobile') || nameOrPlaceholder.includes('phone') || nameOrPlaceholder.includes('aadhaar') || nameOrPlaceholder.includes('account') || nameOrPlaceholder.includes('amount') || nameOrPlaceholder.includes('pincode') || nameOrPlaceholder.includes('pin') || nameOrPlaceholder.includes('otp')) {
                        if (!el.hasAttribute('inputmode')) {
                          el.setAttribute('inputmode', 'numeric');
                        }
                      }
                    }
                  }
                }

                function processAll() {
                  document.querySelectorAll('form').forEach(sanitizeInput);
                  document.querySelectorAll('input, textarea').forEach(sanitizeInput);
                }

                if (document.readyState === 'loading') {
                  document.addEventListener('DOMContentLoaded', processAll);
                } else {
                  processAll();
                }

                document.addEventListener('focusin', function(e) { sanitizeInput(e.target); }, true);
                document.addEventListener('click', function(e) { sanitizeInput(e.target); }, true);
                document.addEventListener('touchstart', function(e) { sanitizeInput(e.target); }, true);

                var observer = new MutationObserver(function(mutations) {
                  mutations.forEach(function(mutation) {
                    mutation.addedNodes.forEach(function(node) {
                      if (node.nodeType === 1) {
                        sanitizeInput(node);
                        if (node.querySelectorAll) {
                          node.querySelectorAll('form, input, textarea').forEach(sanitizeInput);
                        }
                      }
                    });
                  });
                });
                observer.observe(document.documentElement, { childList: true, subtree: true });
              })();
            0:{"P":null,"c":["",""],"q":"","i":false,"f":[[["",{"children":["__PAGE__",{}]},"$undefined","$undefined",16],[["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/0563c538fyhde.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","script","script-0",{"src":"/_next/static/chunks/1h6_r7a6a9osl.js","async":true,"nonce":"$undefined"}],["$","script","script-1",{"src":"/_next/static/chunks/1ntn7efqc-iiw.js","async":true,"nonce":"$undefined"}],["$","script","script-2",{"src":"/_next/static/chunks/3o-yin-2r9ddp.js","async":true,"nonce":"$undefined"}],["$","script","script-3",{"src":"/_next/static/chunks/3aiu8uhh9ykx9.js","async":true,"nonce":"$undefined"}],["$","script","script-4",{"src":"/_next/static/chunks/1s50t5yz2fnzr.js","async":true,"nonce":"$undefined"}],["$","script","script-5",{"src":"/_next/static/chunks/2rpwzaa97r4w2.js","async":true,"nonce":"$undefined"}]],["$","html",null,{"lang":"en","className":"dark","suppressHydrationWarning":true,"style":{"overflowX":"hidden","maxWidth":"100vw"},"children":["$","body",null,{"className":"antialiased min-h-screen bg-slate-950 text-slate-100","suppressHydrationWarning":true,"style":{"overflowX":"hidden","maxWidth":"100vw"},"children":[["$","$L2",null,{"id":"form-input-sanitizer","strategy":"afterInteractive","dangerouslySetInnerHTML":{"__html":"$3"}}],"$L4"]}]}]]}],{"children":["$L5",{},null,false,null]},null,false,null],"$L6",false]],"m":"$undefined","G":["$7",["$L8"]],"S":true,"h":null,"s":"$undefined","l":"$undefined","p":"$undefined","d":"$undefined","b":"koJmotggyk4Jm1WJiLKn7"}
9:I[544636,["/_next/static/chunks/1h6_r7a6a9osl.js","/_next/static/chunks/1ntn7efqc-iiw.js","/_next/static/chunks/3o-yin-2r9ddp.js","/_next/static/chunks/3aiu8uhh9ykx9.js","/_next/static/chunks/1s50t5yz2fnzr.js","/_next/static/chunks/2rpwzaa97r4w2.js"],"default"]
a:I[339756,["/_next/static/chunks/1h6_r7a6a9osl.js","/_next/static/chunks/1ntn7efqc-iiw.js","/_next/static/chunks/3o-yin-2r9ddp.js","/_next/static/chunks/3aiu8uhh9ykx9.js","/_next/static/chunks/1s50t5yz2fnzr.js","/_next/static/chunks/2rpwzaa97r4w2.js"],"default"]
b:I[837457,["/_next/static/chunks/1h6_r7a6a9osl.js","/_next/static/chunks/1ntn7efqc-iiw.js","/_next/static/chunks/3o-yin-2r9ddp.js","/_next/static/chunks/3aiu8uhh9ykx9.js","/_next/static/chunks/1s50t5yz2fnzr.js","/_next/static/chunks/2rpwzaa97r4w2.js"],"default"]
c:I[329306,["/_next/static/chunks/1h6_r7a6a9osl.js","/_next/static/chunks/1ntn7efqc-iiw.js","/_next/static/chunks/3o-yin-2r9ddp.js","/_next/static/chunks/3aiu8uhh9ykx9.js","/_next/static/chunks/1s50t5yz2fnzr.js","/_next/static/chunks/2rpwzaa97r4w2.js","/_next/static/chunks/3gmxly9ppt0ns.js","/_next/static/chunks/3pbatwvycaw23.js","/_next/static/chunks/254sc8oams11j.js"],"default"]
e:I[897367,["/_next/static/chunks/1h6_r7a6a9osl.js","/_next/static/chunks/1ntn7efqc-iiw.js","/_next/static/chunks/3o-yin-2r9ddp.js","/_next/static/chunks/3aiu8uhh9ykx9.js","/_next/static/chunks/1s50t5yz2fnzr.js","/_next/static/chunks/2rpwzaa97r4w2.js"],"OutletBoundary"]
f:"$Sreact.suspense"
11:I[897367,["/_next/static/chunks/1h6_r7a6a9osl.js","/_next/static/chunks/1ntn7efqc-iiw.js","/_next/static/chunks/3o-yin-2r9ddp.js","/_next/static/chunks/3aiu8uhh9ykx9.js","/_next/static/chunks/1s50t5yz2fnzr.js","/_next/static/chunks/2rpwzaa97r4w2.js"],"ViewportBoundary"]
13:I[897367,["/_next/static/chunks/1h6_r7a6a9osl.js","/_next/static/chunks/1ntn7efqc-iiw.js","/_next/static/chunks/3o-yin-2r9ddp.js","/_next/static/chunks/3aiu8uhh9ykx9.js","/_next/static/chunks/1s50t5yz2fnzr.js","/_next/static/chunks/2rpwzaa97r4w2.js"],"MetadataBoundary"]
4:["$","$L9",null,{"children":["$","$La",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$Lb",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[["$","$Lc",null,{}],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]}]
5:["$","$1","c",{"children":["$Ld",null,["$","$Le",null,{"children":["$","$f",null,{"name":"Next.MetadataOutlet","children":"$@10"}]}]]}]
6:["$","$1","h",{"children":[null,["$","$L11",null,{"children":"$L12"}],["$","div",null,{"hidden":true,"children":["$","$L13",null,{"children":["$","$f",null,{"name":"Next.Metadata","children":"$L14"}]}]}],null]}]
8:["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/0563c538fyhde.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]
d:E{"digest":"NEXT_REDIRECT;replace;/dashboard;307;"}
12:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no"}]]
15:I[27201,["/_next/static/chunks/1h6_r7a6a9osl.js","/_next/static/chunks/1ntn7efqc-iiw.js","/_next/static/chunks/3o-yin-2r9ddp.js","/_next/static/chunks/3aiu8uhh9ykx9.js","/_next/static/chunks/1s50t5yz2fnzr.js","/_next/static/chunks/2rpwzaa97r4w2.js"],"IconMark"]
10:null
14:[["$","title","0",{"children":"Pay2Pay FinTech Retailer Platform"}],["$","meta","1",{"name":"description","content":"Enterprise Merchant Banking & Settlement Terminal"}],["$","link","2",{"rel":"icon","href":"/favicon.ico?favicon.2vob68tjqpejf.ico","sizes":"256x256","type":"image/x-icon"}],["$","$L15","3",{}]]
