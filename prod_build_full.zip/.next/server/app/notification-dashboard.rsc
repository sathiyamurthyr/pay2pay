1:"$Sreact.fragment"
2:I[479520,["/_next/static/chunks/1h6_r7a6a9osl.js","/_next/static/chunks/1ntn7efqc-iiw.js","/_next/static/chunks/3o-yin-2r9ddp.js","/_next/static/chunks/3aiu8uhh9ykx9.js","/_next/static/chunks/1s50t5yz2fnzr.js","/_next/static/chunks/2rpwzaa97r4w2.js"],""]
a:I[168027,["/_next/static/chunks/1h6_r7a6a9osl.js","/_next/static/chunks/1ntn7efqc-iiw.js","/_next/static/chunks/3o-yin-2r9ddp.js","/_next/static/chunks/3aiu8uhh9ykx9.js","/_next/static/chunks/1s50t5yz2fnzr.js","/_next/static/chunks/2rpwzaa97r4w2.js"],"default",1]
:HL["/_next/static/chunks/0563c538fyhde.css","style"]
3:Tc62,
              (function() {
                function sanitizeInput(el) {
                  if (!el) return;
                  if (el.tagName === 'FORM') {
                    el.setAttribute('autocomplete', 'off');
                    return;
                  }
                  if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
                    const isPasswordType = el.type === 'password';
                    if (!isPasswordType) {
                      el.setAttribute('autocomplete', 'off');
                      el.setAttribute('autocorrect', 'off');
                      el.setAttribute('autocapitalize', 'off');
                      el.setAttribute('spellcheck', 'false');
                      el.setAttribute('aria-autocomplete', 'none');
                      el.setAttribute('data-lpignore', 'true');
                      el.setAttribute('data-1p-ignore', 'true');
                      el.setAttribute('data-bwignore', 'true');
                      el.setAttribute('data-bitwarden-watching', 'false');
                      
                      const nameOrPlaceholder = (el.name || el.placeholder || el.id || '').toLowerCase();
                      if (nameOrPlaceholder.includes('mobile') || nameOrPlaceholder.includes('phone') || nameOrPlaceholder.includes('aadhaar') || nameOrPlaceholder.includes('account') || nameOrPlaceholder.includes('amount') || nameOrPlaceholder.includes('pincode') || nameOrPlaceholder.includes('pin') || nameOrPlaceholder.includes('otp')) {
                        if (!el.hasAttribute('inputmode')) {
                          el.setAttribute('inputmode', 'numeric');
                        }
                      }
                    }
                  }
                }

                function processAll() {
                  document.querySelectorAll('form').forEach(sanitizeInput);
                  document.querySelectorAll('input, textarea').forEach(sanitizeInput);
                }

                if (document.readyState === 'loading') {
                  document.addEventListener('DOMContentLoaded', processAll);
                } else {
                  processAll();
                }

                document.addEventListener('focusin', function(e) { sanitizeInput(e.target); }, true);
                document.addEventListener('click', function(e) { sanitizeInput(e.target); }, true);
                document.addEventListener('touchstart', function(e) { sanitizeInput(e.target); }, true);

                var observer = new MutationObserver(function(mutations) {
                  mutations.forEach(function(mutation) {
                    mutation.addedNodes.forEach(function(node) {
                      if (node.nodeType === 1) {
                        sanitizeInput(node);
                        if (node.querySelectorAll) {
                          node.querySelectorAll('form, input, textarea').forEach(sanitizeInput);
                        }
                      }
                    });
                  });
                });
                observer.observe(document.documentElement, { childList: true, subtree: true });
              })();
            0:{"P":null,"c":["","notification-dashboard"],"q":"","i":false,"f":[[["",{"children":["(dashboard)",{"children":["notification-dashboard",{"children":["__PAGE__",{}]}]}]},"$undefined","$undefined",16],[["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/0563c538fyhde.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","script","script-0",{"src":"/_next/static/chunks/1h6_r7a6a9osl.js","async":true,"nonce":"$undefined"}],["$","script","script-1",{"src":"/_next/static/chunks/1ntn7efqc-iiw.js","async":true,"nonce":"$undefined"}],["$","script","script-2",{"src":"/_next/static/chunks/3o-yin-2r9ddp.js","async":true,"nonce":"$undefined"}],["$","script","script-3",{"src":"/_next/static/chunks/3aiu8uhh9ykx9.js","async":true,"nonce":"$undefined"}],["$","script","script-4",{"src":"/_next/static/chunks/1s50t5yz2fnzr.js","async":true,"nonce":"$undefined"}],["$","script","script-5",{"src":"/_next/static/chunks/2rpwzaa97r4w2.js","async":true,"nonce":"$undefined"}]],["$","html",null,{"lang":"en","className":"dark","suppressHydrationWarning":true,"style":{"overflowX":"hidden","maxWidth":"100vw"},"children":["$","body",null,{"className":"antialiased min-h-screen bg-slate-950 text-slate-100","suppressHydrationWarning":true,"style":{"overflowX":"hidden","maxWidth":"100vw"},"children":[["$","$L2",null,{"id":"form-input-sanitizer","strategy":"afterInteractive","dangerouslySetInnerHTML":{"__html":"$3"}}],"$L4"]}]}]]}],{"children":["$L5",{"children":["$L6",{"children":["$L7",{},null,false,null]},null,false,"$@8"]},null,false,null]},null,false,null],"$L9",false]],"m":"$undefined","G":["$a",["$Lb"]],"S":true,"h":null,"s":"$undefined","l":"$undefined","p":"$undefined","d":"$undefined","b":"koJmotggyk4Jm1WJiLKn7"}
c:I[544636,["/_next/static/chunks/1h6_r7a6a9osl.js","/_next/static/chunks/1ntn7efqc-iiw.js","/_next/static/chunks/3o-yin-2r9ddp.js","/_next/static/chunks/3aiu8uhh9ykx9.js","/_next/static/chunks/1s50t5yz2fnzr.js","/_next/static/chunks/2rpwzaa97r4w2.js"],"default"]
d:I[339756,["/_next/static/chunks/1h6_r7a6a9osl.js","/_next/static/chunks/1ntn7efqc-iiw.js","/_next/static/chunks/3o-yin-2r9ddp.js","/_next/static/chunks/3aiu8uhh9ykx9.js","/_next/static/chunks/1s50t5yz2fnzr.js","/_next/static/chunks/2rpwzaa97r4w2.js"],"default"]
e:I[837457,["/_next/static/chunks/1h6_r7a6a9osl.js","/_next/static/chunks/1ntn7efqc-iiw.js","/_next/static/chunks/3o-yin-2r9ddp.js","/_next/static/chunks/3aiu8uhh9ykx9.js","/_next/static/chunks/1s50t5yz2fnzr.js","/_next/static/chunks/2rpwzaa97r4w2.js"],"default"]
f:I[329306,["/_next/static/chunks/1h6_r7a6a9osl.js","/_next/static/chunks/1ntn7efqc-iiw.js","/_next/static/chunks/3o-yin-2r9ddp.js","/_next/static/chunks/3aiu8uhh9ykx9.js","/_next/static/chunks/1s50t5yz2fnzr.js","/_next/static/chunks/2rpwzaa97r4w2.js","/_next/static/chunks/3gmxly9ppt0ns.js","/_next/static/chunks/3pbatwvycaw23.js","/_next/static/chunks/254sc8oams11j.js"],"default"]
10:I[92825,["/_next/static/chunks/1h6_r7a6a9osl.js","/_next/static/chunks/1ntn7efqc-iiw.js","/_next/static/chunks/3o-yin-2r9ddp.js","/_next/static/chunks/3aiu8uhh9ykx9.js","/_next/static/chunks/1s50t5yz2fnzr.js","/_next/static/chunks/2rpwzaa97r4w2.js"],"ClientSegmentRoot"]
11:I[216370,["/_next/static/chunks/1h6_r7a6a9osl.js","/_next/static/chunks/1ntn7efqc-iiw.js","/_next/static/chunks/3o-yin-2r9ddp.js","/_next/static/chunks/3aiu8uhh9ykx9.js","/_next/static/chunks/1s50t5yz2fnzr.js","/_next/static/chunks/2rpwzaa97r4w2.js","/_next/static/chunks/1xru5kdxxzacf.js","/_next/static/chunks/1-3m4tsbubshr.js","/_next/static/chunks/07oydxc3oy3tu.js","/_next/static/chunks/0kpm38n8x_hwd.js","/_next/static/chunks/1kja5amzzc0et.js","/_next/static/chunks/0s0gpi7-li4y2.js","/_next/static/chunks/19n21ecb1w1u4.js","/_next/static/chunks/2t8cv--p5k27c.js","/_next/static/chunks/1tr12gyzz-y09.js"],"default"]
12:I[641811,["/_next/static/chunks/1h6_r7a6a9osl.js","/_next/static/chunks/1ntn7efqc-iiw.js","/_next/static/chunks/3o-yin-2r9ddp.js","/_next/static/chunks/3aiu8uhh9ykx9.js","/_next/static/chunks/1s50t5yz2fnzr.js","/_next/static/chunks/2rpwzaa97r4w2.js","/_next/static/chunks/1xru5kdxxzacf.js","/_next/static/chunks/1-3m4tsbubshr.js","/_next/static/chunks/07oydxc3oy3tu.js","/_next/static/chunks/0kpm38n8x_hwd.js","/_next/static/chunks/1kja5amzzc0et.js","/_next/static/chunks/0s0gpi7-li4y2.js","/_next/static/chunks/19n21ecb1w1u4.js","/_next/static/chunks/2t8cv--p5k27c.js","/_next/static/chunks/1tr12gyzz-y09.js","/_next/static/chunks/1o5rbcyut5_s2.js"],"default"]
14:I[347257,["/_next/static/chunks/1h6_r7a6a9osl.js","/_next/static/chunks/1ntn7efqc-iiw.js","/_next/static/chunks/3o-yin-2r9ddp.js","/_next/static/chunks/3aiu8uhh9ykx9.js","/_next/static/chunks/1s50t5yz2fnzr.js","/_next/static/chunks/2rpwzaa97r4w2.js"],"ClientPageRoot"]
15:I[275580,["/_next/static/chunks/1h6_r7a6a9osl.js","/_next/static/chunks/1ntn7efqc-iiw.js","/_next/static/chunks/3o-yin-2r9ddp.js","/_next/static/chunks/3aiu8uhh9ykx9.js","/_next/static/chunks/1s50t5yz2fnzr.js","/_next/static/chunks/2rpwzaa97r4w2.js","/_next/static/chunks/1xru5kdxxzacf.js","/_next/static/chunks/1-3m4tsbubshr.js","/_next/static/chunks/07oydxc3oy3tu.js","/_next/static/chunks/0kpm38n8x_hwd.js","/_next/static/chunks/1kja5amzzc0et.js","/_next/static/chunks/0s0gpi7-li4y2.js","/_next/static/chunks/19n21ecb1w1u4.js","/_next/static/chunks/2t8cv--p5k27c.js","/_next/static/chunks/1tr12gyzz-y09.js","/_next/static/chunks/05t8694upw4vs.js"],"default"]
18:I[897367,["/_next/static/chunks/1h6_r7a6a9osl.js","/_next/static/chunks/1ntn7efqc-iiw.js","/_next/static/chunks/3o-yin-2r9ddp.js","/_next/static/chunks/3aiu8uhh9ykx9.js","/_next/static/chunks/1s50t5yz2fnzr.js","/_next/static/chunks/2rpwzaa97r4w2.js"],"OutletBoundary"]
19:"$Sreact.suspense"
1c:I[897367,["/_next/static/chunks/1h6_r7a6a9osl.js","/_next/static/chunks/1ntn7efqc-iiw.js","/_next/static/chunks/3o-yin-2r9ddp.js","/_next/static/chunks/3aiu8uhh9ykx9.js","/_next/static/chunks/1s50t5yz2fnzr.js","/_next/static/chunks/2rpwzaa97r4w2.js"],"ViewportBoundary"]
1e:I[897367,["/_next/static/chunks/1h6_r7a6a9osl.js","/_next/static/chunks/1ntn7efqc-iiw.js","/_next/static/chunks/3o-yin-2r9ddp.js","/_next/static/chunks/3aiu8uhh9ykx9.js","/_next/static/chunks/1s50t5yz2fnzr.js","/_next/static/chunks/2rpwzaa97r4w2.js"],"MetadataBoundary"]
4:["$","$Lc",null,{"children":["$","$Ld",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$Le",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[["$","$Lf",null,{}],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]}]
5:["$","$1","c",{"children":[[["$","script","script-0",{"src":"/_next/static/chunks/1xru5kdxxzacf.js","async":true,"nonce":"$undefined"}],["$","script","script-1",{"src":"/_next/static/chunks/1-3m4tsbubshr.js","async":true,"nonce":"$undefined"}],["$","script","script-2",{"src":"/_next/static/chunks/07oydxc3oy3tu.js","async":true,"nonce":"$undefined"}],["$","script","script-3",{"src":"/_next/static/chunks/0kpm38n8x_hwd.js","async":true,"nonce":"$undefined"}],["$","script","script-4",{"src":"/_next/static/chunks/1kja5amzzc0et.js","async":true,"nonce":"$undefined"}],["$","script","script-5",{"src":"/_next/static/chunks/0s0gpi7-li4y2.js","async":true,"nonce":"$undefined"}],["$","script","script-6",{"src":"/_next/static/chunks/19n21ecb1w1u4.js","async":true,"nonce":"$undefined"}],["$","script","script-7",{"src":"/_next/static/chunks/2t8cv--p5k27c.js","async":true,"nonce":"$undefined"}],["$","script","script-8",{"src":"/_next/static/chunks/1tr12gyzz-y09.js","async":true,"nonce":"$undefined"}]],["$","$L10",null,{"Component":"$11","slots":{"children":["$","$Ld",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$Le",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[["$","$L12",null,{}],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]},"serverProvidedParams":{"params":{},"promises":["$@13"]}}]]}]
6:["$","$1","c",{"children":[null,["$","$Ld",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$Le",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}]
7:["$","$1","c",{"children":[["$","$L14",null,{"Component":"$15","serverProvidedParams":{"searchParams":{},"params":"$5:props:children:1:props:serverProvidedParams:params","promises":["$@16","$@17"]}}],[["$","script","script-0",{"src":"/_next/static/chunks/05t8694upw4vs.js","async":true,"nonce":"$undefined"}]],["$","$L18",null,{"children":["$","$19",null,{"name":"Next.MetadataOutlet","children":"$@1a"}]}]]}]
1b:[]
8:"$W1b"
9:["$","$1","h",{"children":[null,["$","$L1c",null,{"children":"$L1d"}],["$","div",null,{"hidden":true,"children":["$","$L1e",null,{"children":["$","$19",null,{"name":"Next.Metadata","children":"$L1f"}]}]}],null]}]
b:["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/0563c538fyhde.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]
13:"$5:props:children:1:props:serverProvidedParams:params"
16:{}
17:"$5:props:children:1:props:serverProvidedParams:params"
1d:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no"}]]
20:I[27201,["/_next/static/chunks/1h6_r7a6a9osl.js","/_next/static/chunks/1ntn7efqc-iiw.js","/_next/static/chunks/3o-yin-2r9ddp.js","/_next/static/chunks/3aiu8uhh9ykx9.js","/_next/static/chunks/1s50t5yz2fnzr.js","/_next/static/chunks/2rpwzaa97r4w2.js"],"IconMark"]
1a:null
1f:[["$","title","0",{"children":"Pay2Pay FinTech Retailer Platform"}],["$","meta","1",{"name":"description","content":"Enterprise Merchant Banking & Settlement Terminal"}],["$","link","2",{"rel":"icon","href":"/favicon.ico?favicon.2vob68tjqpejf.ico","sizes":"256x256","type":"image/x-icon"}],["$","$L20","3",{}]]
