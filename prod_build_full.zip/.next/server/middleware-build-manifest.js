globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/koJmotggyk4Jm1WJiLKn7/_buildManifest.js",
    "static/koJmotggyk4Jm1WJiLKn7/_ssgManifest.js",
    "static/koJmotggyk4Jm1WJiLKn7/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0xqeffprgr84u.js",
    "static/chunks/2up_x3pib6pc_.js",
    "static/chunks/2uv575d3zwdsb.js",
    "static/chunks/24j6c6ho8vtzb.js",
    "static/chunks/3nc6x0_y5iwnk.js",
    "static/chunks/turbopack-30yjoycevdymy.js"
  ]
};
