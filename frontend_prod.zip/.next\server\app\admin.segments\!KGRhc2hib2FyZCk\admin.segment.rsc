1:"$Sreact.fragment"
2:I[339756,["/_next/static/chunks/1h6_r7a6a9osl.js","/_next/static/chunks/1ntn7efqc-iiw.js","/_next/static/chunks/3o-yin-2r9ddp.js","/_next/static/chunks/3aiu8uhh9ykx9.js","/_next/static/chunks/1s50t5yz2fnzr.js","/_next/static/chunks/2rpwzaa97r4w2.js"],"default"]
3:I[837457,["/_next/static/chunks/1h6_r7a6a9osl.js","/_next/static/chunks/1ntn7efqc-iiw.js","/_next/static/chunks/3o-yin-2r9ddp.js","/_next/static/chunks/3aiu8uhh9ykx9.js","/_next/static/chunks/1s50t5yz2fnzr.js","/_next/static/chunks/2rpwzaa97r4w2.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"WhwzREHhEJHS0jNIwtN04"}
